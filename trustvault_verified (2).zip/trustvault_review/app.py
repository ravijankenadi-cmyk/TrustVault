"""TrustVault demo API. Review THREATS.md before any public deployment."""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional
from urllib.parse import quote

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerificationError
from fastapi import Depends, FastAPI, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import StreamingResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, create_engine, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./trustvault.db")
STORAGE_DIR = Path(os.getenv("TRUSTVAULT_STORAGE", "./private_files")).resolve()
STORAGE_DIR.mkdir(parents=True, exist_ok=True)
JWT_SECRET = os.getenv("TRUSTVAULT_JWT_SECRET", "")
AUDIT_SECRET = os.getenv("TRUSTVAULT_AUDIT_SECRET", "")
if len(JWT_SECRET) < 32:
    raise RuntimeError("Set TRUSTVAULT_JWT_SECRET to a random secret of at least 32 characters.")
if len(AUDIT_SECRET) < 32 or hmac.compare_digest(JWT_SECRET, AUDIT_SECRET):
    raise RuntimeError("Set TRUSTVAULT_AUDIT_SECRET to a separate random secret of at least 32 characters.")

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False, "timeout": 30} if DATABASE_URL.startswith("sqlite") else {},
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
password_hasher = PasswordHasher()
bearer = HTTPBearer(auto_error=False)
app = FastAPI(title="TrustVault API", version="1.0.0")
MAX_UPLOAD_BYTES = 10 * 1024 * 1024


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20))
    active: Mapped[int] = mapped_column(Integer, default=1)


class Document(Base):
    __tablename__ = "documents"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(255))
    category: Mapped[str] = mapped_column(String(100), default="General")
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    storage_key: Mapped[str] = mapped_column(String(80), unique=True)
    sha256: Mapped[str] = mapped_column(String(64))
    size: Mapped[int] = mapped_column(Integer)
    content_type: Mapped[str] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: now_utc())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: now_utc())


class Grant(Base):
    __tablename__ = "grants"
    __table_args__ = (UniqueConstraint("document_id", "user_id", name="uq_doc_user_grant"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    document_id: Mapped[str] = mapped_column(ForeignKey("documents.id"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    permission: Mapped[str] = mapped_column(String(10))
    granted_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: now_utc())


class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: now_utc())
    actor_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    action: Mapped[str] = mapped_column(String(60))
    document_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    target_user_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    outcome: Mapped[str] = mapped_column(String(20))
    details: Mapped[str] = mapped_column(Text, default="{}")
    previous_hash: Mapped[str] = mapped_column(String(64))
    event_hash: Mapped[str] = mapped_column(String(64), unique=True)


Base.metadata.create_all(engine)


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def db_session():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _normalise_datetime(value: datetime) -> datetime:
    """SQLite drops timezone metadata; normalise all audit timestamps to naive UTC."""
    if value.tzinfo is not None:
        return value.astimezone(timezone.utc).replace(tzinfo=None)
    return value


def _audit_payload(event: AuditEvent | dict, previous_hash: str) -> dict:
    if isinstance(event, dict):
        occurred_at = event["occurred_at"]
        details = event["details"]
        get = event.get
    else:
        occurred_at = _normalise_datetime(event.occurred_at).isoformat()
        details = json.loads(event.details)
        get = lambda key, default=None: getattr(event, key, default)
    return {
        "occurred_at": occurred_at,
        "actor_id": get("actor_id"),
        "action": get("action"),
        "document_id": get("document_id"),
        "target_user_id": get("target_user_id"),
        "outcome": get("outcome"),
        "details": details,
        "previous_hash": previous_hash,
    }


def audit(db: Session, actor_id, action, document_id=None, target_user_id=None, outcome="allowed", details=None):
    """Append a signed event. This starter commits events individually for simplicity."""
    previous = db.scalar(select(AuditEvent).order_by(AuditEvent.id.desc()).limit(1))
    previous_hash = previous.event_hash if previous else "GENESIS"
    occurred = now_utc().replace(tzinfo=None)
    detail_obj = details or {}
    payload = {
        "occurred_at": occurred.isoformat(), "actor_id": actor_id, "action": action,
        "document_id": document_id, "target_user_id": target_user_id, "outcome": outcome,
        "details": detail_obj, "previous_hash": previous_hash,
    }
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    event_hash = hmac.new(AUDIT_SECRET.encode(), canonical.encode(), hashlib.sha256).hexdigest()
    db.add(AuditEvent(
        occurred_at=occurred, actor_id=actor_id, action=action, document_id=document_id,
        target_user_id=target_user_id, outcome=outcome,
        details=json.dumps(detail_obj, sort_keys=True, separators=(",", ":")),
        previous_hash=previous_hash, event_hash=event_hash,
    ))
    db.commit()


def audit_attempt(db: Session, user: Optional[User], action: str, document_id: Optional[str], reason: str):
    try:
        audit(db, user.id if user else None, action, document_id, outcome="denied", details={"reason": reason})
    except Exception:
        db.rollback()
        # Do not turn a denied request into an allow. Operational monitoring should alert on audit failures.
        raise HTTPException(503, "Audit service unavailable")


def get_current_user(
    request: Request,
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(db_session),
):
    if not creds:
        audit_attempt(db, None, "authentication", None, "missing_credentials")
        raise HTTPException(401, "Authentication required", headers={"WWW-Authenticate": "Bearer"})
    try:
        payload = jwt.decode(creds.credentials, JWT_SECRET, algorithms=["HS256"])
        uid = int(payload["sub"])
    except Exception:
        audit_attempt(db, None, "authentication", None, "invalid_or_expired_token")
        raise HTTPException(401, "Invalid or expired token", headers={"WWW-Authenticate": "Bearer"})
    user = db.get(User, uid)
    if not user or not user.active:
        audit_attempt(db, user, "authentication", None, "inactive_or_missing_user")
        raise HTTPException(401, "User inactive or missing", headers={"WWW-Authenticate": "Bearer"})
    return user


def require_role(*roles):
    def dependency(user: User = Depends(get_current_user), db: Session = Depends(db_session)):
        if user.role not in roles:
            audit_attempt(db, user, "role_access", None, "role_not_permitted")
            raise HTTPException(403, "Role not permitted")
        return user
    return dependency


def document_or_404(db: Session, document_id: str, user: Optional[User] = None, action: str = "document_access"):
    doc = db.get(Document, document_id)
    if not doc:
        if user:
            audit_attempt(db, user, action, document_id[:36], "document_not_found")
        raise HTTPException(404, "Document not found")
    return doc


def can_read(db: Session, user: User, doc: Document) -> bool:
    if doc.owner_id == user.id:
        return True
    grant = db.scalar(select(Grant).where(Grant.document_id == doc.id, Grant.user_id == user.id))
    return bool(grant and grant.permission in ("read", "edit"))


def can_edit(db: Session, user: User, doc: Document) -> bool:
    if doc.owner_id == user.id:
        return True
    grant = db.scalar(select(Grant).where(Grant.document_id == doc.id, Grant.user_id == user.id))
    return bool(grant and grant.permission == "edit")


def allowed_doc(db: Session, user: User, doc: Document, action: str):
    permitted = can_read(db, user, doc) if action == "read" else can_edit(db, user, doc)
    if not permitted:
        audit_attempt(db, user, action, doc.id, "missing_document_grant")
        # Do not confirm that an inaccessible document exists.
        raise HTTPException(404, "Document not found")
    return doc


def stream_document(path: Path, document_id: str, actor_id: int, digest: str, size: int):
    """Stream the file and record whether the server-side stream completed."""
    completed = False
    try:
        with open(path, "rb") as stream:
            while True:
                chunk = stream.read(64 * 1024)
                if not chunk:
                    completed = True
                    break
                yield chunk
    finally:
        # Use a new session: response streaming can outlive the endpoint's DB session.
        with SessionLocal() as audit_db:
            audit(audit_db, actor_id, "download_stream", document_id,
                  outcome="completed" if completed else "interrupted",
                  details={"sha256": digest, "size": size})


class LoginBody(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=256)


class GrantBody(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    permission: str = Field(pattern="^(read|edit)$")


class MetadataBody(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    category: str = Field(min_length=1, max_length=100)

    @field_validator("name", "category")
    @classmethod
    def strip_nonempty(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("must not be blank")
        if any(ord(ch) < 32 and ch not in "\t" for ch in value):
            raise ValueError("control characters are not allowed")
        return value


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/auth/login")
def login(body: LoginBody, request: Request, db: Session = Depends(db_session)):
    user = db.scalar(select(User).where(User.username == body.username))
    valid = False
    if user and user.active:
        try:
            valid = password_hasher.verify(user.password_hash, body.password)
        except VerificationError:
            valid = False
        except Exception:
            valid = False
    if not valid:
        audit(db, user.id if user else None, "login", outcome="denied", details={
            "username": body.username, "ip": request.client.host if request.client else "unknown",
        })
        raise HTTPException(401, "Invalid username or password")
    token = jwt.encode({"sub": str(user.id), "exp": now_utc() + timedelta(minutes=20)}, JWT_SECRET, algorithm="HS256")
    audit(db, user.id, "login", details={"ip": request.client.host if request.client else "unknown"})
    return {"access_token": token, "token_type": "bearer", "expires_in_seconds": 1200, "role": user.role}


@app.get("/me")
def me(user: User = Depends(get_current_user)):
    return {"id": user.id, "username": user.username, "role": user.role}


@app.post("/documents")
async def upload_document(
    name: str = Form(...), category: str = Form("General"), file: UploadFile = File(...),
    user: User = Depends(require_role("owner")), db: Session = Depends(db_session),
):
    allowed = {
        ".pdf": ("application/pdf", b"%PDF-"),
        ".png": ("image/png", b"\x89PNG\r\n\x1a\n"),
        ".jpg": ("image/jpeg", b"\xff\xd8\xff"),
        ".jpeg": ("image/jpeg", b"\xff\xd8\xff"),
        ".txt": ("text/plain", None),
    }
    suffix = Path((file.filename or "").replace("\\", "/")).suffix.lower()
    safe_name = name.replace("\\", "/").split("/")[-1].strip()
    safe_category = category.strip()
    if not safe_name or len(safe_name) > 255 or any(ord(ch) < 32 for ch in safe_name):
        audit_attempt(db, user, "upload", None, "invalid_document_name")
        raise HTTPException(400, "Invalid document name")
    if not safe_category or len(safe_category) > 100:
        audit_attempt(db, user, "upload", None, "invalid_category")
        raise HTTPException(400, "Invalid category")
    if suffix not in allowed:
        audit_attempt(db, user, "upload", None, "extension_not_allowed")
        raise HTTPException(415, "File type not allowed")
    data = await file.read(MAX_UPLOAD_BYTES + 1)
    await file.close()
    if not data or len(data) > MAX_UPLOAD_BYTES:
        audit_attempt(db, user, "upload", None, "size_or_empty")
        raise HTTPException(413, "File must be between 1 byte and 10 MB")
    expected_type, signature = allowed[suffix]
    if signature and not data.startswith(signature):
        audit_attempt(db, user, "upload", None, "signature_mismatch")
        raise HTTPException(415, "File content does not match extension")
    if suffix == ".txt":
        try:
            data.decode("utf-8")
        except UnicodeDecodeError:
            audit_attempt(db, user, "upload", None, "invalid_utf8_text")
            raise HTTPException(415, "Text file must be UTF-8")

    doc_id, storage_key = str(uuid.uuid4()), secrets.token_hex(32)
    digest = hashlib.sha256(data).hexdigest()
    path = STORAGE_DIR / storage_key
    try:
        with open(path, "xb") as stream:
            stream.write(data)
        doc = Document(id=doc_id, name=safe_name, category=safe_category, owner_id=user.id,
                       storage_key=storage_key, sha256=digest, size=len(data), content_type=expected_type)
        db.add(doc)
        # audit() commits the new document and its upload event together.
        audit(db, user.id, "upload", doc.id, details={"name": doc.name, "sha256": digest, "size": len(data)})
    except Exception:
        db.rollback()
        path.unlink(missing_ok=True)
        raise HTTPException(500, "Upload could not be saved")
    return {"id": doc.id, "name": doc.name, "category": doc.category, "sha256": digest, "size": len(data)}


@app.get("/documents")
def search_documents(
    name: Optional[str] = Query(default=None, max_length=100),
    owner: Optional[str] = Query(default=None, max_length=80),
    category: Optional[str] = Query(default=None, max_length=100),
    date_from: Optional[str] = Query(default=None, max_length=40),
    date_to: Optional[str] = Query(default=None, max_length=40),
    user: User = Depends(get_current_user), db: Session = Depends(db_session),
):
    # Search results are themselves sensitive metadata. Admin role grants audit
    # visibility only; it must not bypass per-document access control here.
    granted_ids = select(Grant.document_id).where(Grant.user_id == user.id)
    query = select(Document).where(
        (Document.owner_id == user.id) | (Document.id.in_(granted_ids))
    )
    if name:
        query = query.where(Document.name.ilike(f"%{name}%"))
    if category:
        query = query.where(Document.category.ilike(f"%{category}%"))
    if owner:
        owner_user = db.scalar(select(User).where(User.username == owner))
        if not owner_user:
            return []
        query = query.where(Document.owner_id == owner_user.id)
    try:
        parsed_from = datetime.fromisoformat(date_from) if date_from else None
        parsed_to = datetime.fromisoformat(date_to) if date_to else None
    except ValueError:
        raise HTTPException(400, "date_from and date_to must be ISO dates or datetimes")
    if parsed_from and parsed_to and _normalise_datetime(parsed_from) > _normalise_datetime(parsed_to):
        raise HTTPException(400, "date_from must not be after date_to")
    if parsed_from:
        query = query.where(Document.created_at >= _normalise_datetime(parsed_from))
    if parsed_to:
        # Inclusive date-only upper bounds mean the end of that date.
        if len(date_to) == 10:
            parsed_to = parsed_to + timedelta(days=1) - timedelta(microseconds=1)
        query = query.where(Document.created_at <= _normalise_datetime(parsed_to))
    docs = db.scalars(query.order_by(Document.created_at.desc()).limit(200)).all()
    return [{"id": d.id, "name": d.name, "category": d.category, "owner_id": d.owner_id,
             "size": d.size, "created_at": d.created_at.isoformat()} for d in docs]


@app.get("/documents/{document_id}")
def get_document(document_id: str, user: User = Depends(get_current_user), db: Session = Depends(db_session)):
    doc = document_or_404(db, document_id, user, "metadata_read")
    allowed_doc(db, user, doc, "read")
    audit(db, user.id, "metadata_read", doc.id)
    return {"id": doc.id, "name": doc.name, "category": doc.category, "owner_id": doc.owner_id,
            "size": doc.size, "sha256": doc.sha256, "created_at": doc.created_at.isoformat()}


@app.get("/documents/{document_id}/download")
def download_document(document_id: str, user: User = Depends(get_current_user), db: Session = Depends(db_session)):
    doc = document_or_404(db, document_id, user, "download")
    allowed_doc(db, user, doc, "read")
    path = (STORAGE_DIR / doc.storage_key).resolve()
    if path.parent != STORAGE_DIR or not path.is_file():
        audit(db, user.id, "download", doc.id, outcome="error", details={"reason": "storage_missing_or_invalid"})
        raise HTTPException(404, "Document content not found")
    audit(db, user.id, "download_authorized", doc.id, details={"sha256": doc.sha256, "size": doc.size})
    # Never interpolate an untrusted filename into a raw HTTP header.
    ascii_fallback = "".join(ch if 32 <= ord(ch) < 127 and ch not in '"\\;' else "_" for ch in doc.name) or "document"
    encoded_name = quote(doc.name, safe="")
    headers = {
        "Content-Disposition": f'attachment; filename="{ascii_fallback}"; filename*=UTF-8\'\'{encoded_name}',
        "X-Content-Type-Options": "nosniff", "Cache-Control": "no-store, max-age=0",
        "Pragma": "no-cache", "Content-Length": str(doc.size),
    }
    return StreamingResponse(stream_document(path, doc.id, user.id, doc.sha256, doc.size),
                             media_type="application/octet-stream", headers=headers)


@app.patch("/documents/{document_id}")
def update_metadata(document_id: str, body: MetadataBody, user: User = Depends(get_current_user), db: Session = Depends(db_session)):
    doc = document_or_404(db, document_id, user, "metadata_update")
    allowed_doc(db, user, doc, "edit")
    before = {"name": doc.name, "category": doc.category}
    doc.name, doc.category, doc.updated_at = body.name, body.category, now_utc().replace(tzinfo=None)
    audit(db, user.id, "metadata_update", doc.id, details={"before": before, "after": {"name": doc.name, "category": doc.category}})
    return {"id": doc.id, "name": doc.name, "category": doc.category}


@app.post("/documents/{document_id}/grants")
def grant_access(document_id: str, body: GrantBody, user: User = Depends(get_current_user), db: Session = Depends(db_session)):
    doc = document_or_404(db, document_id, user, "grant_access")
    if doc.owner_id != user.id:
        audit_attempt(db, user, "grant_access", doc.id, "not_document_owner")
        raise HTTPException(404, "Document not found")
    target = db.scalar(select(User).where(User.username == body.username, User.active == 1))
    if not target:
        audit(db, user.id, "grant_access", doc.id, outcome="denied", details={"reason": "target_user_not_found", "username": body.username})
        raise HTTPException(404, "Active user not found")
    if target.id == user.id:
        audit_attempt(db, user, "grant_access", doc.id, "self_grant")
        raise HTTPException(400, "Owner already has full control")
    existing = db.scalar(select(Grant).where(Grant.document_id == doc.id, Grant.user_id == target.id))
    try:
        if existing:
            existing.permission, existing.granted_by, existing.created_at = body.permission, user.id, now_utc().replace(tzinfo=None)
        else:
            db.add(Grant(document_id=doc.id, user_id=target.id, permission=body.permission, granted_by=user.id))
        db.flush()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Permission update conflict; retry")
    audit(db, user.id, "grant_access", doc.id, target.id, details={"permission": body.permission})
    return {"document_id": doc.id, "username": target.username, "permission": body.permission}


@app.delete("/documents/{document_id}/grants/{username}")
def revoke_access(document_id: str, username: str, user: User = Depends(get_current_user), db: Session = Depends(db_session)):
    doc = document_or_404(db, document_id, user, "revoke_access")
    if doc.owner_id != user.id:
        audit_attempt(db, user, "revoke_access", doc.id, "not_document_owner")
        raise HTTPException(404, "Document not found")
    target = db.scalar(select(User).where(User.username == username))
    grant = db.scalar(select(Grant).where(Grant.document_id == doc.id, Grant.user_id == target.id)) if target else None
    if not grant:
        audit(db, user.id, "revoke_access", doc.id, target.id if target else None, outcome="not_found", details={"username": username})
        raise HTTPException(404, "Grant not found")
    db.delete(grant)
    audit(db, user.id, "revoke_access", doc.id, target.id, details={"revoked": True})
    return {"revoked": True}


@app.delete("/documents/{document_id}")
def delete_document(document_id: str, user: User = Depends(get_current_user), db: Session = Depends(db_session)):
    doc = document_or_404(db, document_id, user, "delete_document")
    if doc.owner_id != user.id:
        audit_attempt(db, user, "delete_document", doc.id, "not_document_owner")
        raise HTTPException(404, "Document not found")
    snapshot = {"name": doc.name, "sha256": doc.sha256, "size": doc.size}
    path = STORAGE_DIR / doc.storage_key
    quarantine = STORAGE_DIR / f".deleting-{secrets.token_hex(16)}"
    # Record intent, then quarantine the bytes. If the DB commit fails, restore the file.
    audit(db, user.id, "delete_document_attempt", doc.id, details=snapshot)
    moved_to_quarantine = False
    try:
        if path.exists():
            path.replace(quarantine)
            moved_to_quarantine = True
        db.query(Grant).filter(Grant.document_id == doc.id).delete(synchronize_session=False)
        db.delete(doc)
        # Commit deletion and success event together.
        audit(db, user.id, "delete_document", doc.id, outcome="allowed", details=snapshot)
    except Exception:
        db.rollback()
        if moved_to_quarantine and quarantine.exists():
            quarantine.replace(path)
        audit(db, user.id, "delete_document", doc.id, outcome="error", details={"reason": "delete_failed", **snapshot})
        raise HTTPException(500, "Document could not be deleted cleanly")
    if moved_to_quarantine:
        quarantine.unlink(missing_ok=True)
    return {"deleted": True}


@app.get("/admin/audit")
def admin_audit(limit: int = Query(default=100, ge=1, le=500), user: User = Depends(require_role("admin")), db: Session = Depends(db_session)):
    events = db.scalars(select(AuditEvent).order_by(AuditEvent.id.desc()).limit(limit)).all()
    return [{"id": e.id, "occurred_at": e.occurred_at.isoformat(), "actor_id": e.actor_id,
             "action": e.action, "document_id": e.document_id, "target_user_id": e.target_user_id,
             "outcome": e.outcome, "details": json.loads(e.details), "previous_hash": e.previous_hash,
             "event_hash": e.event_hash} for e in events]


@app.get("/admin/audit/verify")
def verify_audit(user: User = Depends(require_role("admin")), db: Session = Depends(db_session)):
    events = db.scalars(select(AuditEvent).order_by(AuditEvent.id.asc())).all()
    previous_hash = "GENESIS"
    for event in events:
        payload = _audit_payload(event, previous_hash)
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        expected = hmac.new(AUDIT_SECRET.encode(), canonical.encode(), hashlib.sha256).hexdigest()
        if event.previous_hash != previous_hash or not hmac.compare_digest(expected, event.event_hash):
            return {"valid": False, "failed_event_id": event.id, "events_checked": event.id - 1}
        previous_hash = event.event_hash
    return {"valid": True, "events_checked": len(events)}


@app.post("/dev/bootstrap")
def bootstrap(db: Session = Depends(db_session)):
    if os.getenv("TRUSTVAULT_BOOTSTRAP") != "1":
        raise HTTPException(404, "Not found")
    if db.scalar(select(User.id).limit(1)):
        raise HTTPException(409, "Users already exist")
    seed = [
        ("admin", "AdminPass-ChangeMe-2026!", "admin"),
        ("owner", "OwnerPass-ChangeMe-2026!", "owner"),
        ("viewer", "ViewerPass-ChangeMe-2026!", "viewer"),
    ]
    for username, password, role in seed:
        db.add(User(username=username, password_hash=password_hasher.hash(password), role=role, active=1))
    db.commit()
    audit(db, None, "bootstrap", outcome="allowed", details={"accounts_created": ["admin", "owner", "viewer"]})
    return {"created": ["admin", "owner", "viewer"], "warning": "Development credentials only; never deploy these credentials."}
