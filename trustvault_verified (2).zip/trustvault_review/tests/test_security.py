"""Adversarial API tests for TrustVault's core security promises."""
import os
from pathlib import Path

os.environ["TRUSTVAULT_JWT_SECRET"] = "test-jwt-secret-at-least-32-characters-long"
os.environ["TRUSTVAULT_AUDIT_SECRET"] = "test-audit-secret-at-least-32-characters-long"
os.environ["DATABASE_URL"] = "sqlite:///./test_trustvault.db"
os.environ["TRUSTVAULT_STORAGE"] = "./test_private_files"
os.environ["TRUSTVAULT_BOOTSTRAP"] = "1"

from fastapi.testclient import TestClient
from sqlalchemy import select

from app import app, AuditEvent, Base, Document, Grant, SessionLocal, User, engine, password_hasher

client = TestClient(app)
PASSWORD = "Correct-Test-Password-123!"


def setup_module():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    storage = Path("./test_private_files")
    storage.mkdir(exist_ok=True)
    for item in storage.iterdir():
        if item.is_file():
            item.unlink()
    with SessionLocal() as db:
        db.add_all([
            User(username="admin", password_hash=password_hasher.hash(PASSWORD), role="admin", active=1),
            User(username="owner1", password_hash=password_hasher.hash(PASSWORD), role="owner", active=1),
            User(username="owner2", password_hash=password_hasher.hash(PASSWORD), role="owner", active=1),
            User(username="viewer1", password_hash=password_hasher.hash(PASSWORD), role="viewer", active=1),
            User(username="viewer2", password_hash=password_hasher.hash(PASSWORD), role="viewer", active=1),
            User(username="disabled", password_hash=password_hasher.hash(PASSWORD), role="viewer", active=0),
        ])
        db.commit()


def token(username, password=PASSWORD):
    response = client.post("/auth/login", json={"username": username, "password": password})
    assert response.status_code == 200, response.text
    return response.json()["access_token"]


def auth(token_value):
    return {"Authorization": f"Bearer {token_value}"}


def upload(owner_token, name="private.txt", content=b"secret content", category="HR", upload_name=None):
    response = client.post(
        "/documents", headers=auth(owner_token), data={"name": name, "category": category},
        files={"file": (upload_name or name, content, "text/plain")},
    )
    return response


def create_doc(name="private.txt", content=b"secret content", category="HR"):
    return upload(token("owner1"), name=name, content=content, category=category)


def test_health_and_authentication_required():
    assert client.get("/health").json() == {"status": "ok"}
    assert client.get("/documents").status_code == 401
    assert client.get("/me").status_code == 401


def test_other_owner_cannot_read_download_edit_delete_or_share():
    owner1, owner2 = token("owner1"), token("owner2")
    response = upload(owner1)
    assert response.status_code == 200, response.text
    document_id = response.json()["id"]
    assert client.get(f"/documents/{document_id}", headers=auth(owner2)).status_code == 404
    assert client.get(f"/documents/{document_id}/download", headers=auth(owner2)).status_code == 404
    assert client.patch(f"/documents/{document_id}", headers=auth(owner2), json={"name": "stolen", "category": "HR"}).status_code == 404
    assert client.delete(f"/documents/{document_id}", headers=auth(owner2)).status_code == 404
    assert client.post(f"/documents/{document_id}/grants", headers=auth(owner2), json={"username": "viewer1", "permission": "read"}).status_code == 404
    assert client.delete(f"/documents/{document_id}/grants/viewer1", headers=auth(owner2)).status_code == 404


def test_grant_read_then_revoke_blocks_existing_token_and_url():
    owner, viewer = token("owner1"), token("viewer1")
    response = upload(owner, name="contract.txt", content=b"contract", category="Legal")
    assert response.status_code == 200
    document_id = response.json()["id"]
    url = f"/documents/{document_id}/download"
    assert client.get(url, headers=auth(viewer)).status_code == 404
    assert client.post(f"/documents/{document_id}/grants", headers=auth(owner), json={"username": "viewer1", "permission": "read"}).status_code == 200
    download = client.get(url, headers=auth(viewer))
    assert download.status_code == 200 and download.content == b"contract"
    assert client.delete(f"/documents/{document_id}/grants/viewer1", headers=auth(owner)).status_code == 200
    assert client.get(url, headers=auth(viewer)).status_code == 404


def test_read_grant_cannot_edit_metadata_but_edit_grant_can():
    owner, viewer = token("owner1"), token("viewer1")
    document_id = upload(owner).json()["id"]
    grant_url = f"/documents/{document_id}/grants"
    patch_url = f"/documents/{document_id}"
    assert client.post(grant_url, headers=auth(owner), json={"username": "viewer1", "permission": "read"}).status_code == 200
    assert client.patch(patch_url, headers=auth(viewer), json={"name": "new.txt", "category": "Legal"}).status_code == 404
    assert client.post(grant_url, headers=auth(owner), json={"username": "viewer1", "permission": "edit"}).status_code == 200
    assert client.patch(patch_url, headers=auth(viewer), json={"name": "new.txt", "category": "Legal"}).status_code == 200


def test_viewer_cannot_upload_grant_or_delete():
    viewer = token("viewer1")
    assert upload(viewer).status_code == 403
    document_id = create_doc().json()["id"]
    assert client.post(f"/documents/{document_id}/grants", headers=auth(viewer), json={"username": "viewer2", "permission": "read"}).status_code == 404
    assert client.delete(f"/documents/{document_id}", headers=auth(viewer)).status_code == 404


def test_admin_can_view_audit_but_has_no_automatic_document_access():
    owner, admin = token("owner1"), token("admin")
    document_id = upload(owner).json()["id"]
    assert client.get(f"/documents/{document_id}", headers=auth(admin)).status_code == 404
    assert client.get(f"/documents/{document_id}/download", headers=auth(admin)).status_code == 404
    assert client.get("/admin/audit", headers=auth(admin)).status_code == 200
    assert client.get("/admin/audit/verify", headers=auth(admin)).json()["valid"] is True


def test_admin_search_does_not_leak_ungranted_document_metadata():
    owner, admin = token("owner1"), token("admin")
    private_id = upload(owner, name="confidential-merger.txt", category="Legal").json()["id"]
    response = client.get("/documents?name=confidential-merger", headers=auth(admin))
    assert response.status_code == 200
    assert all(item["id"] != private_id for item in response.json())
    assert client.post(
        f"/documents/{private_id}/grants", headers=auth(owner),
        json={"username": "admin", "permission": "read"},
    ).status_code == 200
    visible = client.get("/documents?name=confidential-merger", headers=auth(admin))
    assert [item["id"] for item in visible.json()] == [private_id]


def test_non_admin_cannot_read_audit():
    assert client.get("/admin/audit", headers=auth(token("owner1"))).status_code == 403
    assert client.get("/admin/audit/verify", headers=auth(token("viewer1"))).status_code == 403


def test_search_does_not_leak_other_owners_documents():
    owner1, owner2, viewer = token("owner1"), token("owner2"), token("viewer2")
    private_id = upload(owner1, name="secret-salary.txt", category="Payroll").json()["id"]
    upload(owner2, name="other-contract.txt", category="Legal")
    results = client.get("/documents?name=secret", headers=auth(owner2))
    assert results.status_code == 200 and results.json() == []
    assert client.get("/documents", headers=auth(viewer)).json() == []
    assert client.post(f"/documents/{private_id}/grants", headers=auth(owner1), json={"username": "viewer2", "permission": "read"}).status_code == 200
    visible = client.get("/documents?name=secret", headers=auth(viewer)).json()
    assert [item["id"] for item in visible] == [private_id]


def test_upload_rejects_unsupported_extension_and_mismatched_signature():
    owner = token("owner1")
    unsupported = client.post("/documents", headers=auth(owner), data={"name": "script.exe", "category": "General"}, files={"file": ("script.exe", b"MZ executable", "application/octet-stream")})
    mismatch = client.post("/documents", headers=auth(owner), data={"name": "fake.pdf", "category": "General"}, files={"file": ("fake.pdf", b"not a pdf", "application/pdf")})
    assert unsupported.status_code == 415
    assert mismatch.status_code == 415


def test_upload_rejects_empty_invalid_utf8_and_oversized_files():
    owner = token("owner1")
    empty = client.post("/documents", headers=auth(owner), data={"name": "empty.txt", "category": "General"}, files={"file": ("empty.txt", b"", "text/plain")})
    invalid = client.post("/documents", headers=auth(owner), data={"name": "bad.txt", "category": "General"}, files={"file": ("bad.txt", b"\xff\xfe", "text/plain")})
    oversized = client.post("/documents", headers=auth(owner), data={"name": "large.txt", "category": "General"}, files={"file": ("large.txt", b"x" * (10 * 1024 * 1024 + 1), "text/plain")})
    assert empty.status_code == 413
    assert invalid.status_code == 415
    assert oversized.status_code == 413


def test_upload_sanitises_windows_path_in_document_name_and_download_header():
    owner = token("owner1")
    response = upload(owner, name=r"..\payroll\staff.txt", content=b"safe", upload_name="staff.txt")
    assert response.status_code == 200
    assert response.json()["name"] == "staff.txt"
    document_id = response.json()["id"]
    viewer = token("viewer1")
    client.post(f"/documents/{document_id}/grants", headers=auth(owner), json={"username": "viewer1", "permission": "read"})
    download = client.get(f"/documents/{document_id}/download", headers=auth(viewer))
    assert download.status_code == 200
    assert "\r" not in download.headers["content-disposition"]
    assert "\n" not in download.headers["content-disposition"]


def test_invalid_and_expired_or_malformed_tokens_are_rejected_and_audited():
    response = client.get("/documents", headers=auth("not.a.real.token"))
    assert response.status_code == 401
    with SessionLocal() as db:
        assert db.scalar(select(AuditEvent).where(AuditEvent.action == "authentication", AuditEvent.outcome == "denied")) is not None


def test_inactive_user_cannot_login():
    response = client.post("/auth/login", json={"username": "disabled", "password": PASSWORD})
    assert response.status_code == 401


def test_bad_login_is_generic_and_audited():
    response = client.post("/auth/login", json={"username": "owner1", "password": "wrong-password"})
    assert response.status_code == 401
    assert response.json()["detail"] == "Invalid username or password"
    with SessionLocal() as db:
        assert db.scalar(select(AuditEvent).where(AuditEvent.action == "login", AuditEvent.outcome == "denied")) is not None


def test_document_not_found_attempt_is_audited():
    response = client.get("/documents/00000000-0000-0000-0000-000000000000", headers=auth(token("viewer1")))
    assert response.status_code == 404
    with SessionLocal() as db:
        event = db.scalar(select(AuditEvent).where(AuditEvent.action == "metadata_read", AuditEvent.document_id == "00000000-0000-0000-0000-000000000000"))
        assert event is not None and event.outcome == "denied"


def test_search_date_validation_and_filters():
    owner = token("owner1")
    response = upload(owner, name="date-filter.txt", category="Engineering")
    assert response.status_code == 200
    assert client.get("/documents?date_from=not-a-date", headers=auth(owner)).status_code == 400
    assert client.get("/documents?date_from=2026-10-22&date_to=2026-10-21", headers=auth(owner)).status_code == 400
    assert len(client.get("/documents?name=date-filter&category=Engineering", headers=auth(owner)).json()) >= 1


def test_grant_validation_and_unknown_target():
    owner = token("owner1")
    document_id = create_doc().json()["id"]
    assert client.post(f"/documents/{document_id}/grants", headers=auth(owner), json={"username": "viewer1", "permission": "owner"}).status_code == 422
    assert client.post(f"/documents/{document_id}/grants", headers=auth(owner), json={"username": "missing", "permission": "read"}).status_code == 404


def test_delete_removes_document_file_and_metadata():
    owner = token("owner1")
    response = create_doc(name="delete-me.txt", content=b"delete this")
    document_id = response.json()["id"]
    with SessionLocal() as db:
        doc = db.get(Document, document_id)
        file_path = Path("./test_private_files") / doc.storage_key
        assert file_path.exists()
    assert client.delete(f"/documents/{document_id}", headers=auth(owner)).status_code == 200
    assert not file_path.exists()
    assert client.get(f"/documents/{document_id}", headers=auth(owner)).status_code == 404


def test_audit_chain_verifies_and_detects_tampering():
    admin = token("admin")
    assert client.get("/admin/audit/verify", headers=auth(admin)).json()["valid"] is True
    with SessionLocal() as db:
        event = db.scalar(select(AuditEvent).where(AuditEvent.action == "upload").limit(1))
        assert event is not None
        original = event.details
        event.details = '{"tampered":true}'
        db.commit()
    result = client.get("/admin/audit/verify", headers=auth(admin)).json()
    assert result["valid"] is False
    with SessionLocal() as db:
        event = db.get(AuditEvent, event.id)
        event.details = original
        db.commit()
    assert client.get("/admin/audit/verify", headers=auth(admin)).json()["valid"] is True


def test_bootstrap_is_disabled_when_environment_flag_is_off(monkeypatch):
    monkeypatch.setenv("TRUSTVAULT_BOOTSTRAP", "0")
    assert client.post("/dev/bootstrap").status_code == 404
    monkeypatch.setenv("TRUSTVAULT_BOOTSTRAP", "1")


def test_read_download_has_no_store_headers():
    owner, viewer = token("owner1"), token("viewer2")
    document_id = upload(owner).json()["id"]
    assert client.post(f"/documents/{document_id}/grants", headers=auth(owner), json={"username": "viewer2", "permission": "read"}).status_code == 200
    response = client.get(f"/documents/{document_id}/download", headers=auth(viewer))
    assert response.status_code == 200
    assert response.headers["cache-control"] == "no-store, max-age=0"
    assert response.headers["x-content-type-options"] == "nosniff"
    with SessionLocal() as db:
        event = db.scalar(select(AuditEvent).where(AuditEvent.action == "download_stream", AuditEvent.document_id == document_id))
        assert event is not None and event.outcome == "completed"


def test_missing_credentials_attempt_is_audited():
    response = client.get("/documents")
    assert response.status_code == 401
    with SessionLocal() as db:
        event = db.scalar(select(AuditEvent).where(AuditEvent.action == "authentication", AuditEvent.outcome == "denied", AuditEvent.details.contains("missing_credentials")))
        assert event is not None


def test_role_denial_is_audited():
    response = upload(token("viewer1"))
    assert response.status_code == 403
    with SessionLocal() as db:
        event = db.scalar(select(AuditEvent).where(AuditEvent.action == "role_access", AuditEvent.outcome == "denied"))
        assert event is not None


def test_search_rejects_mixed_timezone_reversed_range_cleanly():
    owner = token("owner1")
    response = client.get("/documents?date_from=2026-10-22T00:00:00%2B00:00&date_to=2026-10-21T00:00:00", headers=auth(owner))
    assert response.status_code == 400
