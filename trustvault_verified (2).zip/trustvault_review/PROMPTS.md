# TrustVault AI-use log — working record

This record describes AI-assisted review and changes made during the current revision on **2026-10-21**. It is not a substitute for the candidate's own ongoing notes. The repository owner must add real commit URLs after committing each corresponding change. **Do not invent commit IDs or backdate commits.** This file is not submission-ready until the pending commit references are replaced with actual links and the candidate adds future entries while working.

## Entry 1 — 2026-10-21 — Authorization / IDOR review
- **Prompt (fair summary):** Compare the current TrustVault code with the problem statement and determine whether the test cases cover unauthorized cross-user document access.
- **AI output:** The starter had three tests, covering some cross-owner access, revocation and viewer restrictions.
- **What was wrong:** Three tests did not cover the complete endpoint surface, search isolation, role denials, admin content access, unknown IDs, or the distinction between read and edit grants. A green result was not evidence that all security requirements were satisfied.
- **What changed:** Expanded the automated suite to test cross-owner metadata/download/edit/delete/share/revoke attempts, read-vs-edit grants, admin content isolation, role denial and search visibility. The current suite has 25 tests; all pass locally at this revision.
- **Commit:** Pending — add the real commit URL after committing this change.

## Entry 2 — 2026-10-21 — Authorization / revocation behavior
- **Prompt (fair summary):** Check whether revoking a document grant stops the same viewer token and download path from working.
- **AI output:** The code checks current grants on each download and does not issue public or presigned URLs.
- **What was wrong / limitation found:** The original tests covered one read-grant/revoke path but did not demonstrate the difference between read and edit grants or confirm that an existing JWT does not preserve document permission. Revocation also cannot recall bytes already downloaded by a recipient.
- **What changed:** Added tests for read-only metadata edit denial, edit-grant allowance, and reuse of the same viewer token/path after revocation. Documented that revocation prevents future server requests, not copies already saved.
- **Commit:** Pending — add the real commit URL after committing this change.

## Entry 3 — 2026-10-21 — Audit trail integrity and denied attempts
- **Prompt (fair summary):** Review whether the audit trail can detect event modification and whether denied access attempts are represented.
- **AI output:** The app uses HMAC-SHA256 signatures and a previous-event hash chain.
- **What was wrong:** The earlier test suite did not alter an audit event to prove verification fails. A same-database chain also cannot reliably detect deletion of the final events without an external checkpoint, and an administrator who has both database write access and the HMAC secret can forge a replacement chain.
- **What changed:** Added a test that changes an event's details, verifies the chain fails, restores the original details and verifies it passes again. Added audit events for missing/invalid credentials, role denial, unknown document IDs and download stream completion/interruption. Expanded `THREATS.md` to state the external-anchor limitation.
- **Commit:** Pending — add the real commit URL after committing this change.

## Entry 4 — 2026-10-21 — Upload validation and filename handling
- **Prompt (fair summary):** Review upload validation, filename path traversal, malformed file types, oversized uploads and download response headers.
- **AI output:** The starter already used an extension allowlist, basic file signatures, a 10 MiB cap and random storage keys.
- **What was wrong:** Basic signatures do not establish that a file is safe or fully valid. Display names needed stronger path-separator handling and safe `Content-Disposition` encoding. Production also needs reverse-proxy request-size limits and malware scanning.
- **What changed:** Normalised slash and backslash handling in display names, rejected blank/control-character metadata, safely encoded download filenames, added no-store/nosniff headers and expanded negative tests for unsupported extensions, signature mismatch, empty/invalid UTF-8 and oversized uploads. Remaining limitations are documented rather than described as solved.
- **Commit:** Pending — add the real commit URL after committing this change.

## Entry 5 — 2026-10-21 — Search, date validation and regression testing
- **Prompt (fair summary):** Run the tests, expand edge-case coverage, and make sure search filters fail cleanly for invalid date ranges.
- **AI output:** The first expanded run found a failing search-isolation test because the test reused a viewer who already had a grant from an earlier test.
- **What was wrong:** The failure was caused by test data leaking across test cases, not by the search access predicate. The test's assumption that this viewer had no grants was false. The date-range comparison also needed normalization when one datetime had a timezone and the other did not.
- **What changed:** The search test now uses a viewer not previously granted that document. Date input is parsed and normalised before range comparison, and a mixed-timezone reversed-range test was added. Final local result after the admin-search regression test: `25 passed`; `python -m compileall -q app.py tests` completed successfully.
- **Commit:** Pending — add the real commit URL after committing this change.

## Entry 6 — 2026-10-21 — Admin search metadata leak / regression test
- **Prompt (fair summary):** Compare the actual implementation against the rule that admins can inspect audit events but must not automatically access documents; test search as well as direct metadata and download endpoints.
- **AI output:** Direct metadata and download routes denied an admin without a grant, but the search query bypassed the owner/grant filter for the admin role.
- **What was wrong:** Admin search could expose document names, categories, sizes and owner IDs even though the role description said administrators had no automatic document access. The prior test checked direct access only and missed this route.
- **What changed:** Removed the admin search bypass and added a regression test proving an admin cannot find an ungranted document until the owner explicitly grants access. The full suite now reports `25 passed`. I also performed a mutation check by temporarily removing the download authorization call: the cross-user and revocation tests failed as expected; the original code was restored and the full suite passed again.
- **Commit:** Pending — add the real commit URL after committing this change.

## Reusable project instruction
Treat every document ID and client-supplied filename as untrusted. Enforce object-level authorization on the server for every request; default deny. Do not issue public or presigned file URLs. Test negative cases using a different authenticated user. Do not call an audit log immutable unless it is protected independently from the application and database administrators. Report test results and remaining risks honestly.

## Before submission
- Replace every `Pending` commit field with a real link to the corresponding commit.
- Continue adding dated entries as work happens; do not manufacture a week of history or rewrite commit dates.
- Add the exact prompts/context files actually used, if any, and verify every statement against the real repository.
