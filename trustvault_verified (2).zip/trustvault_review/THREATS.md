# TrustVault threat model

This threat model describes the current demo implementation. The tests named below are in `tests/test_security.py`; not every accepted risk is fully mitigated. Revisit this file after each deployment change.

## Threats and controls

| Threat | Control in this implementation | Test / remaining limitation |
|---|---|---|
| IDOR: another owner guesses a document ID | Each metadata, download, edit, grant, revoke and delete route checks owner/grant on the server; inaccessible IDs return 404 | `test_other_owner_cannot_read_download_edit_delete_or_share`; extend to fuzz all routes and alternate HTTP methods |
| Viewer uses an endpoint intended for owners | Owner role required for upload; ownership required for sharing/deletion | `test_viewer_cannot_upload_grant_or_delete` |
| Read-only grant edits metadata | `read` grants are distinct from `edit` grants | `test_read_grant_cannot_edit_metadata_but_edit_grant_can` |
| Revoked grant continues to work | No public or presigned URLs; current grant is checked on every download request | `test_grant_read_then_revoke_blocks_existing_token_and_url`; a previously downloaded copy cannot be recalled |
| Admin account reads confidential file by default | Admin role grants audit visibility, not document-content permission | `test_admin_can_view_audit_but_has_no_automatic_document_access` |
| Search endpoint leaks other users' names/metadata | All roles, including admins, are restricted to owned or explicitly granted documents before filters | `test_search_does_not_leak_other_owners_documents`, `test_admin_search_does_not_leak_ungranted_document_metadata` |
| Invalid/expired token or disabled account | JWT signature/expiry checked; active account checked on every authenticated request | `test_invalid_and_expired_or_malformed_tokens_are_rejected_and_audited`, `test_inactive_user_cannot_login`; token revocation list is not implemented |
| Password guessing / account enumeration | Argon2 hashes and generic login error | `test_bad_login_is_generic_and_audited`; no rate limiting/account lockout yet |
| Missing credentials or role denial is invisible | Authentication and role-denial events are appended to audit log | `test_missing_credentials_attempt_is_audited`, `test_role_denial_is_audited`; framework-level validation failures (e.g. some 422 responses) are not all logged |
| Unknown document IDs are probed | Authenticated missing-ID attempts are audited and return 404 | `test_document_not_found_attempt_is_audited`; anonymous requests without credentials are logged as authentication failures, not tied to a document |
| Extension/MIME spoofing | Extension allowlist and basic PDF/PNG/JPEG signature checks; UTF-8 check for text | `test_upload_rejects_unsupported_extension_and_mismatched_signature`, `test_upload_rejects_empty_invalid_utf8_and_oversized_files`; signatures do not prove a file is safe or fully valid |
| Upload exhausts memory/disk | Application reads at most 10 MiB + 1 byte and rejects larger content | `test_upload_rejects_empty_invalid_utf8_and_oversized_files`; proxy/request body limits and streaming-to-disk are still needed for production |
| Filename path traversal/header injection | Random storage keys; normalise path separators in display name; encode Content-Disposition filename | `test_upload_sanitises_windows_path_in_document_name_and_download_header`; test additional Unicode/control-character cases before deployment |
| Storage path tampering | Download resolves path and verifies its parent is the configured storage directory | Current tests do not directly mutate DB storage keys; private filesystem permissions remain necessary |
| Audit event content modified | HMAC-SHA256 signature plus previous-event hash chain | `test_audit_chain_verifies_and_detects_tampering`; signing secret must remain separate and protected |
| Audit event deleted/truncated by DB administrator | **Not fully mitigated**: hash chain detects edits in the surviving chain but cannot reliably detect deletion of the tail without an external anchor | Export signed checkpoints/events to independently administered append-only/WORM storage in production |
| Audit signing secret compromised | Separate secret from JWT secret and env-based configuration | A holder of the audit secret who can rewrite the DB can forge a chain; use secret manager and external immutable sink |
| Download event falsely implies file was fully received | Records authorization and stream completion/interruption separately | `test_read_download_has_no_store_headers`; server-side completion cannot prove a human read the content or that every network byte reached the client |
| Delete fails partway | Attempt and outcome events are recorded | Filesystem and database are not one atomic transaction; use quarantine/transactional outbox and recovery procedures in production |
| Concurrent grant/revoke/download races | Authorization is rechecked at request start | No strict cross-worker linearization guarantee; define and test concurrency semantics before production |
| Cached copy survives revocation | No caching headers and no public URLs | A recipient can save bytes already downloaded; this cannot be technically recalled by this app |

## Roles and intended permissions

- **Admin:** inspect and verify audit activity; no automatic right to read document contents.
- **Owner:** upload, read, edit metadata, grant/revoke access, and delete own documents.
- **Viewer:** read/download only when granted `read` or `edit` access; cannot upload or manage grants.
- **Edit grantee:** read/download and edit document metadata; cannot grant access or delete the document.

All document access decisions are server-side. UI hiding alone is not a security control.

## Accepted risks / deliberately not built

- SQLite and local disk are for local demo use, not high availability or durable production storage.
- No MFA, SSO, login rate limiting, password reset, malware scanning, content disarm, document versioning, recovery/retention workflow, external sharing, groups/folders or full-text file-content search.
- Files are not encrypted individually at rest by this application; rely on encrypted disks/object storage and key management if deployed.
- HMAC chaining in the same database is tamper-evident against limited attackers, not immutable evidence against a database administrator who can access the key or truncate the tail.
- JWTs last 20 minutes. Deactivating an account blocks requests immediately because the database is checked on every request, but individual tokens are not otherwise revocable.
- The upload code buffers up to 10 MiB in memory. Reverse-proxy request limits and streaming upload implementation are required for production.
- A successful stream indicates the server completed iterating the file, not proof that a person read or retained it.

## Adversarial checks to perform before submission

1. Remove the authorization check in `download_document`; the cross-user and revoke tests must fail.
2. Repeat IDOR checks against every route and with malformed/guessed IDs.
3. Try role changes, inactive accounts, expired tokens, invalid JWT signatures, and repeated login failures.
4. Alter and delete audit events, including the final event; verify what is detected and document what cannot be detected without an external anchor.
5. Try valid extensions with malformed files, path-like Unicode filenames, zero-byte files, and oversized request bodies.
6. Run concurrent grant/revoke/download tests and confirm the expected revocation point.
7. Test the deployed service in an incognito window and ensure the private storage path is not publicly reachable.
