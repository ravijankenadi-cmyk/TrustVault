"""Create TrustVault database tables after environment variables are configured."""
from app import Base, engine

if __name__ == "__main__":
    Base.metadata.create_all(engine)
    print("TrustVault database schema is ready.")
