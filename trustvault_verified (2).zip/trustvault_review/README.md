# TrustVault — secure document-sharing API

TrustVault is a learning/demo API for per-document permissions, private file storage and a tamper-evident audit trail. It uses Python, FastAPI, SQLAlchemy, SQLite by default, Argon2 password hashes and HMAC-SHA256 chained audit events.

> **Security status:** this is an improved assessment starter, not a production-certified document vault. Run the tests and read `THREATS.md`. The local database and filesystem are intended for development/demo use only.

## Features

- Three roles: `admin`, `owner`, `viewer`.
- Owners upload, search, update metadata, grant/revoke per-document `read` or `edit` access, and delete their documents.
- `read` grants allow metadata and download; `edit` grants also allow metadata edits. Editing file bytes/version history is not implemented.
- Admins can inspect and verify audit events but do **not** automatically get access to document contents.
- Each metadata/download/edit/delete/grant/revoke request checks authorization on the server. Non-authorized document access returns 404 to avoid confirming that the document exists.
- Revocation takes effect on the next request because the application checks the current grant on every request. Previously downloaded copies cannot be recalled.
- Upload allowlist: PDF, PNG, JPEG and UTF-8 text; maximum 10 MiB; basic signature checks for PDF/PNG/JPEG.
- Audit events cover login success/failure, missing/invalid credentials, role denials, unknown/inaccessible document IDs, upload outcomes, metadata actions, grant/revoke, delete and download stream completion/interruption.
- Admin audit verification checks HMAC signatures and the hash chain.

## Requirements

- Python 3.11+
- pip

## Run locally (Windows PowerShell)

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
$env:TRUSTVAULT_JWT_SECRET = (python -c "import secrets; print(secrets.token_hex(32))")
$env:TRUSTVAULT_AUDIT_SECRET = (python -c "import secrets; print(secrets.token_hex(32))")
$env:TRUSTVAULT_BOOTSTRAP = "1"
uvicorn app:app --reload
```

## Run locally (macOS/Linux)

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
export TRUSTVAULT_JWT_SECRET="$(python -c 'import secrets; print(secrets.token_hex(32))')"
export TRUSTVAULT_AUDIT_SECRET="$(python -c 'import secrets; print(secrets.token_hex(32))')"
export TRUSTVAULT_BOOTSTRAP=1
uvicorn app:app --reload
```

Open `http://127.0.0.1:8000/docs`. Call `POST /dev/bootstrap` once. It creates these **development-only** accounts:

- `admin` / `AdminPass-ChangeMe-2026!`
- `owner` / `OwnerPass-ChangeMe-2026!`
- `viewer` / `ViewerPass-ChangeMe-2026!`

Never deploy with these credentials or with `TRUSTVAULT_BOOTSTRAP=1`. The route returns 404 unless the environment flag is enabled and returns 409 if any user already exists. For a real deployment, provision accounts through a separate secure admin process.

## Initialise database schema explicitly (optional)

The app creates missing tables on startup for convenience. After setting the required secrets, you can also run:

```bash
python scripts/init_db.py
```

## Run automated tests

```bash
python -m pytest -q
```

The included suite currently contains 25 tests covering cross-user access, read/edit grants, immediate revocation, role restrictions, search isolation, malformed tokens, inactive users, upload validation, audit-denial events, audit tampering, and response headers. A passing suite is not a guarantee against all attacks.

## Permission model

| Endpoint | Caller | Authorization rule |
|---|---|---|
| `GET /health` | Anyone | Health status only |
| `POST /auth/login` | Anyone | Generic failure response; login outcome audited |
| `GET /me` | Authenticated user | Returns own identity only |
| `POST /documents` | Owner | Upload a new document |
| `GET /documents` | Authenticated user | Owner's docs + explicitly granted docs; admin may search metadata globally |
| `GET /documents/{id}` | Owner or read/edit grantee | Read metadata |
| `GET /documents/{id}/download` | Owner or read/edit grantee | Re-check grant for every request; stream is audited |
| `PATCH /documents/{id}` | Owner or edit grantee | Change name/category metadata only |
| `POST /documents/{id}/grants` | Document owner only | Grant or update `read` / `edit` permission to a named active user |
| `DELETE /documents/{id}/grants/{username}` | Document owner only | Revoke named user's grant |
| `DELETE /documents/{id}` | Document owner only | Delete file, grants and metadata; action audited |
| `GET /admin/audit` | Admin only | Read recent audit events |
| `GET /admin/audit/verify` | Admin only | Verify event signatures and chain links |
| `POST /dev/bootstrap` | Only when explicitly enabled | Local demo account setup; disable before deployment |

Interactive OpenAPI documentation is available at `/docs` while the app is running.

## Storage and audit design

- The client filename is metadata only. Files are stored under random opaque storage keys in `TRUSTVAULT_STORAGE` (default `./private_files`), never under user-controlled paths.
- Storage must not be exposed as a static/public web directory.
- Each audit event signs a canonical representation of its fields with HMAC-SHA256 and links to the prior event hash.
- The HMAC secret must be separate from the JWT secret. If an attacker can alter the database and obtain the HMAC secret, they can forge a replacement chain. Because the chain is in the same database, deletion/truncation of a tail may not be detectable without an external checkpoint.

## Before public deployment

1. Disable the bootstrap route/flag and replace demo users with securely provisioned accounts.
2. Use a managed database, migrations, backups, and a durable private storage volume/object store with restrictive IAM.
3. Use HTTPS, strong secret management, rate limiting, login throttling, MFA/SSO as appropriate, and account lifecycle controls.
4. Export audit events/checkpoints to independently administered append-only/WORM storage; alert on audit failures.
5. Add antivirus/content-disarm scanning, stronger file-format parsing, request-body limits at the proxy, monitoring and incident response.
6. Review transaction boundaries and concurrent grant/revoke/download behavior; run an independent security review.
7. Use a persistent disk. Ephemeral hosting filesystems can lose uploaded documents after restart/redeploy.
8. Do not claim production readiness until these controls and the deployed system have been tested.

See `THREATS.md` for accepted risks and `PROMPTS.md` for the AI-use record. Fill the AI-use record honestly as work proceeds; do not invent commits or claim work/tests that did not happen.
